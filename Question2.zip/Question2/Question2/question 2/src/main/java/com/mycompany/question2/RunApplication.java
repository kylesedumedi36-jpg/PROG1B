package com.mycompany.question2;

import java.util.Scanner;

/** Main class for the console sales application. */
public class RunApplication {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("==============================================");
        System.out.println("      ELECTRONIC STORE CONSOLE SALES");
        System.out.println("==============================================");
        System.out.println("Select a console device type:");
        System.out.println("1. PS5");
        System.out.println("2. Xbox");
        System.out.println("3. Nintendo Switch");
        System.out.print("Enter your choice: ");

        int choice = input.nextInt();
        input.nextLine();

        String consoleType;
        switch (choice) {
            case 1 -> consoleType = "PS5";
            case 2 -> consoleType = "Xbox";
            case 3 -> consoleType = "Nintendo Switch";
            default -> {
                System.out.println("Invalid console device choice.");
                input.close();
                return;
            }
        }

        System.out.print("Enter the store name: ");
        String storeName = input.nextLine();

        System.out.print("Enter the total amount of sales: ");
        int totalSales = input.nextInt();

        ConsoleSales consoleSales = new ConsoleSales(consoleType, storeName, totalSales);
        consoleSales.printReport();

        input.close();
    }
}
