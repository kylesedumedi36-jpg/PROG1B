package com.mycompany.question2;

/** Abstract class that stores console sales information. */
public abstract class Console implements IConsole {

    protected String consoleType;
    protected String storeName;
    protected int totalSales;

    public Console(String consoleType, String storeName, int totalSales) {
        this.consoleType = consoleType;
        this.storeName = storeName;
        this.totalSales = totalSales;
    }

    @Override
    public String getConsoleType() {
        return consoleType;
    }

    @Override
    public int getTotalSales() {
        return totalSales;
    }

    public String getStoreName() {
        return storeName;
    }

    public abstract void printReport();
}
