package com.mycompany.question2;

public interface IConsole {
    String getConsoleType();
    int getTotalSales();
}
