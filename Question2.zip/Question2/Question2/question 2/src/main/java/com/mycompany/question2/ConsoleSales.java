package com.mycompany.question2;

/** Concrete subclass of Console. */
public class ConsoleSales extends Console {

    public ConsoleSales(String consoleType, String storeName, int totalSales) {
        super(consoleType, storeName, totalSales);
    }

    @Override
    public void printReport() {
        System.out.println();
        System.out.println("==============================================");
        System.out.println("        ELECTRONIC STORE SALES REPORT");
        System.out.println("==============================================");
        System.out.println("Console Device Type : " + getConsoleType());
        System.out.println("Store Name          : " + getStoreName());
        System.out.println("Total Amount Sales  : " + getTotalSales());
        System.out.println("==============================================");
    }
}
