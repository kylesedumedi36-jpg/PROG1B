package com.mycompany.question1;

/**
 * Question 1 - Number 1 Electronics
 * Displays yearly sales for three gaming consoles in three cities.
 */
public class Question1 {

    public static void main(String[] args) {
        // Single-dimensional arrays
        String[] cities = {"Cape Town", "Port Elizabeth", "Pretoria"};
        String[] consoles = {"PS5", "Xbox", "Nintendo Switch"};

        // Two-dimensional array: rows = cities, columns = consoles
        int[][] sales = {
            {1000, 2000, 3000},
            {2000, 3000, 4000},
            {1500, 1100, 1200}
        };

        System.out.println("===============================================================");
        System.out.println("              NUMBER 1 ELECTRONICS - YEARLY SALES");
        System.out.println("===============================================================");
        System.out.printf("%-20s %-10s %-10s %-18s %-12s%n",
                "City", consoles[0], consoles[1], consoles[2], "Total Sales");
        System.out.println("---------------------------------------------------------------");

        int highestTotal = 0;
        String cityWithMostSales = "";

        for (int i = 0; i < cities.length; i++) {
            int cityTotal = 0;

            for (int j = 0; j < consoles.length; j++) {
                cityTotal += sales[i][j];
            }

            System.out.printf("%-20s %-10d %-10d %-18d %-12d%n",
                    cities[i], sales[i][0], sales[i][1], sales[i][2], cityTotal);

            if (cityTotal > highestTotal) {
                highestTotal = cityTotal;
                cityWithMostSales = cities[i];
            }
        }

        System.out.println("---------------------------------------------------------------");
        System.out.println("City with the most gaming console sales: " + cityWithMostSales);
        System.out.println("Highest total sales: " + highestTotal);
        System.out.println("===============================================================");
    }
}
